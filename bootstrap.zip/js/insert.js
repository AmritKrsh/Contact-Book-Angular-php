var myApp = angular
				.module("myModule",[])
				.controller("myController",function($scope,$http){
					$scope.insertdata=function(){
						$http.post("insert.php",{'name':$scope.name,'city':$scope.city, 'phone':$scope.phone, 'salary':$scope.salary})
						.success(function(){
							$scope.msg="data inserted";
						})
					}
					
				});